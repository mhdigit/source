import cv2
import base64
import numpy as np

import matplotlib.pyplot as plt
from PIL import ImageFont, ImageDraw, Image
from persian_tools import plate
from datetime import datetime


from hezar.models import Model
from ultralytics import YOLO



detect_model = YOLO(f"./models/plate-detector.pt")
ocr_model  = Model.load("hezarai/crnn-fa-64x256-license-plate-recognition")





def detect_plate(img,conf=0.5):
    result = []
    # img = cv2.imread(image_path)
    # https://docs.ultralytics.com/usage/cfg/#predict-settings save_crop
    output = detect_model.predict(source=img,conf=conf)[0]
    speed = output.speed
    time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    if output.boxes.conf.numel() == 0:
        return {
     
        'speed':speed,
        'is_detected':False,
        'process_speed':speed,
        'meta':{'is_valid_plate':False,"time":time}
        }
    index = output.boxes.conf.argmax()
    boxes = output.boxes.xyxy[index]
    x1,y1,x2,y2 = map(int,boxes)
    cropped_img = img[y1:y2, x1:x2]
    cv2.imwrite(f'plate_cropped.jpg',cropped_img )
    cropped_plate = img_to_base64(cropped_img)
    plate_text = ocr_model.predict(f'plate_cropped.jpg')
    plate_text = plate_text[0]['text'][::-1]
    try:
        meta = plate.get_info(plate_text)
        meta['is_valid_plate'] = plate.is_valid(plate_text)
    except:
        meta = {'is_valid_plate':False}

    box = [x1,y1,x2,y2]
    annotated_img = annotate_img(img,plate_text,box)
    annotated_img = img_to_base64(annotated_img)

    return {
        'text':plate_text,
        'box':box,
        "meta":{**meta,'time':time},
        "process_speed":speed,
        'cropped_plate':cropped_plate,
        'annotated_img':annotated_img,
        'is_detected':True

    }


def annotate_img(img,text,box):
    x1,y1,x2,y2 = box
    org = [x1, y1-20]
    color = (0, 0, 255)  # Red color BGR
    img = Image.fromarray(img)
    draw = ImageDraw.Draw(img)
    draw.rectangle([(x1, y1), (x2, y2)], outline =color,)

    font = ImageFont.truetype("./static/fonts/BZar.ttf", size=23)
    # font = ImageFont.truetype("./fonts/BZar.ttf", size=23)
    
    draw.rectangle([(org[0], org[1]), (org[0]+(len(text)*11), org[1]+15)], fill =color)
    draw.text(org, text[:-2]+' '+text[-2:], fill=(255,255,255), font=font)
    img = np.array(img)
    return img




# ======================================================= Util ========================================================

def to_plate_format(text):
    persian_to_english={"ا":"A","ب":"B","پ":"P","ت":"T","ث":"TH","ج":"J","چ":"CH","ح":"H","خ":"KH","د":"D","ذ":"DH","ر":"R","ز":"Z","ژ":"ZH","س":"S","ش":"SH","ص":"Sa","ض":"Zz","ط":"Ta","ظ":"Za","ع":"An","غ":"GH","ف":"F","ق":"GH","ک":"K","گ":"G","ل":"L","م":"M","ن":"N","و":"V","ه":"H","ی":"Y","۰":"0","۱":"1","۲":"2","۳":"3","۴":"4","۵":"5","۶":"6","۷":"7","۸":"8","۹":"9",}
    t = ''.join(persian_to_english[ch] for ch in text)
    t = '{0} {1} {2} |{3}'.format(t[:2],t[2:-5],t[-5:-2],t[-2:])
    return t

def decode_image(image_data):
    # Decode the image
    encoded_data = image_data.split(',')[1]
    nparr = np.frombuffer(base64.b64decode(encoded_data), np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    return img

def img_to_base64(img,format='.jpg'):
    # Convert images to base64
    _, img_encoded = cv2.imencode(format, img)
    img_base64 = base64.b64encode(img_encoded).decode('utf-8')
    return f'data:image/{format[1:]};base64,{img_base64}'







