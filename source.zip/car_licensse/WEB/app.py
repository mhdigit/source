from flask import Flask, render_template, request, jsonify


from model import detect_plate,decode_image

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/detect',methods=['GET'])
def plate_detection():
    return render_template('plate_detection.html')

@app.route('/detect', methods=['POST'])
def detect():
    data = request.json
    image_data = data['image']

    img = decode_image(image_data)
    result = detect_plate(img)

    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
