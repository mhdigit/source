from flask import Flask, render_template, request, jsonify
import face_recognition
import cv2
import numpy as np
import base64
import os
from datetime import datetime

##################################### Test with 2 face pic

app = Flask(__name__)

# Directory containing known faces
TELORANCE = 0.5
KNOWN_FACES_DIR = "./dataset"
ENCODE_FACES_FILE = './known_face_encodings.npy'





def update_db(directory_path,save=True,save_path='./known_face_encodings.npy'):
    print('[start to updating database ...]')
    known_face_encodings = []
    errors= []
    # Walk through directory
    d = os.walk(directory_path)
    known_names = next(d)[1]
    c = len(known_names)
    for i,(dirpath, dirnames, filenames) in enumerate(d):
        try:
            filename = filenames[0]
            if filename.endswith(".jpg") or filename.endswith(".png"):
                filepath = os.path.join(dirpath, filename)
                image = face_recognition.load_image_file(filepath)
                face_encoding = face_recognition.face_encodings(image)[0]
                known_face_encodings.append(face_encoding)
                name = known_names[i]
                print(f'{i}/{c} {name}'+' '*20,end='\r')
        except:
            print('')
            print('error in ',i)
            errors.append(i)
            known_face_encodings.append(np.zeros(128))

    print('')
    print('[finish]')
    if save:
        np.save(save_path, np.array(known_face_encodings))

    return known_face_encodings ,errors



def get_image_by_name(name):
    path = f'{KNOWN_FACES_DIR}/{name}/'
    img = next(os.walk(path))[-1][0]
    image_path = path+img
    image = cv2.imread(image_path)
    
    # Encode the image as JPEG to a byte array
    _, buffer = cv2.imencode('.jpg', image)
    img_bytes = buffer.tobytes()
    
    # Encode the byte array to a base64 string
    img_base64 = base64.b64encode(img_bytes).decode('utf-8')
    # Add the data URI prefix for a JPEG image
    img_base64_with_prefix = f"data:image/jpeg;base64,{img_base64}"
    return img_base64_with_prefix




def get_info(directory_path):
    d = os.walk(directory_path)
    known_names = next(d)[1]
    known_face_info = [{"name":name , "id": i} for i,name in enumerate(known_names)]
    return  known_face_info

known_face_info = get_info(KNOWN_FACES_DIR)
known_face_encodings = np.load(ENCODE_FACES_FILE)


# def update_db():
#     global known_face_encodings
#     global known_face_info
#     known_face_encodings = []
#     known_face_info = []

#     # Load known faces
#     for filename in os.listdir(KNOWN_FACES_DIR):
#         if filename.endswith(".jpg") or filename.endswith(".png"):
#             filepath = os.path.join(KNOWN_FACES_DIR, filename)
#             image = face_recognition.load_image_file(filepath)
#             face_encoding = face_recognition.face_encodings(image)[0]
#             known_face_encodings.append(face_encoding)

#             # Extract user info from the filename (assuming 'username_userid.jpg' format)
#             user_info = filename.rsplit('.', 1)[0]  # Remove file extension
#             user_name, user_id = user_info.split('_')
#             known_face_info.append({"name": user_name, "id": user_id})
#     return known_face_encodings,known_face_info


@app.route('/')
def index():
    # _ = update_db()
    return render_template('index.html')

@app.route('/info')
def db_info():
    
    return jsonify({'known_face_info':known_face_info})

@app.route('/recognize', methods=['POST'])
def recognize():
    data = request.json
    image_data = data['image'].split(",")[1]
    image = base64.b64decode(image_data)
    nparr = np.fromstring(image, np.uint8)
    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    # Find all the faces and face encodings in the frame
    try:
        face_locations = face_recognition.face_locations(frame)
        face_encodings = face_recognition.face_encodings(frame, face_locations)
    except:
        return {"recognized":False}

    recognized = False
    user_name = ""
    user_id = ""
    original_img = ""
   

    for face_encoding in face_encodings:

        # matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
        distance = face_recognition.face_distance(known_face_encodings, face_encoding)
        match_index = distance.argmin()
        tolerance = distance[match_index]
        if tolerance<=TELORANCE:
            recognized = True
            user_info = known_face_info[match_index]
            user_name = user_info["name"]
            user_id = user_info["id"]
            original_img = get_image_by_name(user_name)
            break
    else:
        tolerance = '?'
    time = datetime.now()
    date = time.strftime('%Y-%m-%d')
    clock = time.strftime('%H:%M:%S')

    return jsonify({

        "recognized": recognized,
        "user_name": user_name,
        "user_id": user_id,
        'user_img':data['image'],
        "original_img":original_img,
        "date":date,
        "time":clock,
        'tolerance':tolerance,
    })

if __name__ == '__main__':
    app.run(debug=True)
