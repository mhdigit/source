from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('upload/', views.upload_file, name='upload_file'),
    path('files/', views.file_list, name='file_list'),
    path('share/<int:file_id>/', views.share_file, name='share_file'),
    path('download/<int:file_id>/', views.download_file, name='download_file'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
]
