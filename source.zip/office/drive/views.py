from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden, HttpResponse
from django.contrib.auth.models import User 
from .models import File
from .forms import UploadFileForm

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'drive/login.html', {'error': 'Invalid credentials'})
    return render(request, 'drive/login.html')

def user_logout(request):
    logout(request)
    return redirect('login')

@login_required
def home(request):
    return render(request, 'drive/home.html')

@login_required
def upload_file(request):
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            new_file = form.save(commit=False)
            new_file.owner = request.user
            new_file.save()
            return redirect('file_list')
    else:
        form = UploadFileForm()
    return render(request, 'drive/upload_file.html', {'form': form})

@login_required
def file_list(request):
    # Files owned by the user or shared with the user
    owned_files = File.objects.filter(owner=request.user)
    shared_files = File.objects.filter(shared_with=request.user)
    files = owned_files | shared_files
    # files = File.objects.all()
    return render(request, 'drive/file_list.html', {'files': files})

@login_required
def share_file(request, file_id):
    file = get_object_or_404(File, id=file_id)
    if request.method == 'POST':
        user_id = request.POST['user_id']
        user = User.objects.get(id=user_id)
        file.shared_with.add(user)
        return redirect('file_list')
    users = User.objects.exclude(id=request.user.id)
    return render(request, 'drive/share_file.html', {'file': file, 'users': users})

@login_required
def download_file(request, file_id):
    file = get_object_or_404(File, id=file_id)
    if not file.is_accessible_by(request.user):
        return HttpResponseForbidden("You do not have permission to access this file.")

    response = HttpResponse(file.file, content_type='application/octet-stream')
    response['Content-Disposition'] = f'attachment; filename={file.file.name}'
    return response
