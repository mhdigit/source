from django.http import HttpResponse
from django.conf import settings
from django.shortcuts import get_object_or_404
from drive.models import File
import os



def has_access(user, file_path):
    # Example: Check if the file is owned by the user

    file = get_object_or_404(File, file__exact=file_path)
    print(file.shared_with.all())
    #add shared
    return file.owner == user or user in file.shared_with.all()


def serve_media_file(request, path):
    # Ensure the user is authenticated and has permission to access the file
    if not request.user.is_authenticated or not has_access(request.user, path):
        return HttpResponse("Unauthorized", status=403)
    
    # Determine the file path
    file_path = os.path.join(settings.MEDIA_ROOT, path)

    # Serve the file
    with open(file_path, 'rb') as file:
        response = HttpResponse(file.read())
        response['Content-Type'] = 'application/octet-stream'
        return response
    

