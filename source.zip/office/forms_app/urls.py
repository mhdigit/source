from django.urls import path
from . import views


urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('form/create/', views.form_create, name='form_create'),
    path('form/<int:form_id>/edit/', views.form_edit, name='form_edit'),
    path('form/<int:form_id>/', views.form_detail, name='form_detail'),
    path('form/success/', views.form_success, name='form_success'),
    path('form/<int:form_id>/submissions/', views.view_submissions, name='view_submissions'),
    path('response/<int:response_id>/compare/', views.compare_answers, name='compare_answers'),
]
