from django.shortcuts import render, get_object_or_404, redirect
from .models import Form, Question, Choice, Response, Answer
from .forms import FormResponseForm

def dashboard(request):
    if request.method == 'POST':
        if 'delete_form' in request.POST:
            form_id = request.POST.get('delete_form')
            Form.objects.filter(id=form_id).delete()
            return redirect('dashboard')
    forms = Form.objects.all()
    return render(request, 'forms_app/dashboard.html', {'forms': forms})

def form_create(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        form = Form.objects.create(title=title, description=description)
        return redirect('form_edit', form_id=form.id)
    return render(request, 'forms_app/form_create.html')


def form_edit(request, form_id):
    form = get_object_or_404(Form, id=form_id)
    questions = form.questions.all()
    if request.method == 'POST':
        if 'delete_question' in request.POST:
            question_id = request.POST.get('delete_question')
            Question.objects.filter(id=question_id).delete()
            return redirect('form_edit', form_id=form.id)
        elif 'edit_question' in request.POST:
            question_id = request.POST.get('edit_question')
            question_text = request.POST.get(f'question_text_{question_id}')
            correct_answer = request.POST.get(f'correct_answer_{question_id}', '')
            question = Question.objects.get(id=question_id)
            question.question_text = question_text
            question.correct_answer = correct_answer
            question.save()
            choices = request.POST.getlist(f'choices_{question_id}')
            Choice.objects.filter(question=question).delete()
            for choice_text in choices:
                Choice.objects.create(question=question, choice_text=choice_text)
            return redirect('form_edit', form_id=form.id)
        else:
            question_text = request.POST.get('question_text')
            question_type = request.POST.get('question_type')
            correct_answer = request.POST.get('correct_answer', '')
            question = Question.objects.create(form=form, question_text=question_text, question_type=question_type, correct_answer=correct_answer)
            if question_type in [Question.RADIO, Question.CHECKBOX]:
                choices = request.POST.getlist('choices')
                for choice in choices:
                    Choice.objects.create(question=question, choice_text=choice)
            return redirect('form_edit', form_id=form.id)
    return render(request, 'forms_app/form_edit.html', {'form': form, 'questions': questions})


def form_detail(request, form_id):
    form = get_object_or_404(Form, id=form_id)
    if request.method == 'POST':
        form_response = FormResponseForm(request.POST, questions=form.questions.all())
        if form_response.is_valid():
            response = Response.objects.create(form=form)
            for question in form.questions.all():
                answer_data = form_response.cleaned_data['question_%s' % question.id]
                if question.question_type == Question.TEXT:
                    Answer.objects.create(response=response, question=question, text=answer_data)
                elif question.question_type in [Question.RADIO, Question.CHECKBOX]:
                    choices = question.choices.filter(id__in=answer_data)
                    for choice in choices:
                        Answer.objects.create(response=response, question=question, choice=choice)
            return redirect('form_success')
    else:
        form_response = FormResponseForm(questions=form.questions.all())
    return render(request, 'forms_app/form_detail.html', {'form': form, 'form_response': form_response})

def form_success(request):
    return render(request, 'forms_app/form_success.html')

def view_submissions(request, form_id):
    form = get_object_or_404(Form, id=form_id)
    responses = Response.objects.filter(form=form)
    return render(request, 'forms_app/view_submissions.html', {'form': form, 'responses': responses})

def compare_answers(request, response_id):
    response = get_object_or_404(Response, id=response_id)
    answers = response.answers.all()
    return render(request, 'forms_app/compare_answers.html', {'response': response, 'answers': answers})
