from django import forms
from .models import Question

class FormResponseForm(forms.Form):
    def __init__(self, *args, **kwargs):
        questions = kwargs.pop('questions')
        super(FormResponseForm, self).__init__(*args, **kwargs)
        for question in questions:
            if question.question_type == Question.TEXT:
                self.fields['question_%s' % question.id] = forms.CharField(label=question.question_text, required=True)
            elif question.question_type == Question.RADIO:
                choices = [(choice.id, choice.choice_text) for choice in question.choices.all()]
                self.fields['question_%s' % question.id] = forms.ChoiceField(label=question.question_text, choices=choices, widget=forms.RadioSelect, required=True)
            elif question.question_type == Question.CHECKBOX:
                choices = [(choice.id, choice.choice_text) for choice in question.choices.all()]
                self.fields['question_%s' % question.id] = forms.MultipleChoiceField(label=question.question_text, choices=choices, widget=forms.CheckboxSelectMultiple, required=True)
            elif question.question_type == Question.DATE:
                self.fields['question_%s' % question.id] = forms.DateField(label=question.question_text, required=True, widget=forms.DateInput(attrs={'type': 'date'}))
            elif question.question_type == Question.NUMBER:
                self.fields['question_%s' % question.id] = forms.IntegerField(label=question.question_text, required=True)


