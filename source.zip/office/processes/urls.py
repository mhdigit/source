from django.urls import path
from .views import ProcessListView, ProcessDetailView, ProcessCreateView, ProcessStateCreateView

urlpatterns = [
    path('', ProcessListView.as_view(), name='process-list'),
    path('process/<int:pk>/', ProcessDetailView.as_view(), name='process-detail'),
    path('process/new/', ProcessCreateView.as_view(), name='process-create'),
    path('processstate/new/', ProcessStateCreateView.as_view(), name='processstate-create'),
]