from django import forms
from .models import Process, ProcessStage, Response

class ProcessForm(forms.ModelForm):
    class Meta:
        model = Process
        fields = ['name', 'description']

class ProcessStageForm(forms.ModelForm):
    class Meta:
        model = ProcessStage
        fields = ['title', 'description', 'order']

class ResponseForm(forms.ModelForm):
    class Meta:
        model = Response
        fields = ['responder_ip']
