from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, View,DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import Answer, Process, ProcessStage , Form, Response,ProcessState
from .forms import ProcessForm, ProcessStageForm , ResponseForm

# ================== process view ======================
class ProcessListView(LoginRequiredMixin, ListView):
    model = Process
    template_name = 'processes/process_list.html'
    context_object_name = 'processes'

class ProcessDetailView(LoginRequiredMixin, DetailView):
    model = Process
    template_name = 'processes/process_detail.html'
    context_object_name = 'process'

class ProcessCreateView(LoginRequiredMixin, CreateView):
    model = Process
    fields = ['name', 'description']
    template_name = 'processes/process_form.html'
    success_url = reverse_lazy('process-list')

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)

class ProcessStateCreateView(LoginRequiredMixin, CreateView):
    model = ProcessState
    fields = ['process', 'description', 'current_step', 'status', 'assigned_to']
    template_name = 'processes/process_state_form.html'
    success_url = reverse_lazy('process-list')

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)

# ====================== form view =================================

class FormCreateView(CreateView):
    model = Response
    form_class = ResponseForm
    template_name = 'processes/form_response.html'

    def form_valid(self, form):
        form.instance.responder = self.request.user
        return super().form_valid(form)




class FormResponseView(View):
    def get(self, request, form_id):
        form = get_object_or_404(Form, pk=form_id)
        questions = form.questions.all()
        return render(request, 'processes/form_response.html', {'form': form, 'questions': questions})

    def post(self, request, form_id):
        form = get_object_or_404(Form, pk=form_id)
        response = Response.objects.create(
            response_to=form,
            responder_ip=request.META['REMOTE_ADDR'],
            responder=request.user
        )
        for question in form.questions.all():
            answer_text = request.POST.get(f'question_{question.id}')
            if answer_text:
                Answer.objects.create(
                    response=response,
                    answer=answer_text,
                    answer_to=question
                )
        return redirect('response-success', response_id=response.id)

class ResponseSuccessView(View):
    def get(self, request, response_id):
        response = get_object_or_404(Response, pk=response_id)
        return render(request, 'processes/response_success.html', {'response': response})