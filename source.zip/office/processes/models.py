from django.db import models
from django.contrib.auth.models import User


# =============================== Process =======================================================



class Process(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)

    created_by = models.ForeignKey(User, null=True, on_delete=models.SET_NULL, related_name='created_processes')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class ProcessStage(models.Model):
    process = models.ForeignKey(Process, on_delete=models.CASCADE, related_name='stages')
    title = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    order = models.PositiveIntegerField()
    # is_completed = models.BooleanField(default=False)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return f"{self.process.name} - {self.title}"

#TODO: add ProcessFlow or ProcessState 

class ProcessState(models.Model):

    STATUS_PENDING = 'pending'
    STATUS_COMPLETED = 'completed'
    STATUS_FAILED = 'failed'

    STATUS_CHOICES = [
        (STATUS_PENDING, 'Pending'),
        (STATUS_COMPLETED, 'Completed'),
        (STATUS_FAILED, 'Failed'),
    ]

    process = models.ForeignKey(Process, on_delete=models.CASCADE, related_name='states')
    code = models.CharField(max_length=30,null=True,blank=True)
    description = models.TextField(blank=True)
    current_step = models.PositiveIntegerField(default=0)
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=STATUS_PENDING,
    )

    created_by = models.ForeignKey(User, null=True, on_delete=models.SET_NULL, related_name='created_process_states')
    assigned_to = models.ForeignKey(User, null=True, on_delete=models.SET_NULL, related_name='process_states')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.process.name} - Step {self.current_step} - {self.status}"




# =============================== Form =======================================================
class Form(models.Model):
    
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    process_stage = models.ForeignKey(ProcessStage, on_delete=models.CASCADE, related_name="forms")
    allowed_users = models.ManyToManyField(User, related_name="allowed_forms")
    edit_after_submit = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title

class QuestionType(models.Model):
    type_name = models.CharField(max_length=20)

    def __str__(self):
        return self.type_name

class Question(models.Model):
    form = models.ForeignKey(Form, related_name="questions", on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    question_type = models.ForeignKey(QuestionType, null=True, on_delete=models.SET_NULL)
    required = models.BooleanField(default=False)

    def __str__(self):
        return self.title

class Choice(models.Model):
    question = models.ForeignKey(Question, related_name="choices", on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=200)

    def __str__(self):
        return self.choice_text

class Response(models.Model):
    
    form = models.ForeignKey(Form, related_name="responses", on_delete=models.CASCADE)
    process_state = models.ForeignKey(ProcessState, related_name="related_response", on_delete=models.CASCADE)
    responder = models.ForeignKey(User, null=True, on_delete=models.CASCADE, related_name="responses")
    responder_ip = models.CharField(max_length=30)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class Answer(models.Model):
    response = models.ForeignKey(Response, related_name="answers", on_delete=models.CASCADE)
    question = models.ForeignKey(Question, related_name="answers", on_delete=models.CASCADE)
    answer_text = models.TextField()

    def __str__(self):
        return self.answer_text
    
class Attachment(models.Model):
    response = models.ForeignKey(Response, on_delete=models.CASCADE, related_name="attachments")
    file = models.FileField(upload_to='attachments/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
