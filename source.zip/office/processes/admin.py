
from django.contrib import admin
from .models import  ProcessState,Process, ProcessStage, Attachment, Form, QuestionType, Question, Choice, Response, Answer



class ProcessStageInline(admin.TabularInline):
    model = ProcessStage
    extra = 1

@admin.register(Process)
class ProcessAdmin(admin.ModelAdmin):
    list_display = ('name','description', 'created_by', 'created_at', 'updated_at')
    inlines = [ProcessStageInline]

@admin.register(ProcessState)
class ProcessStateAdmin(admin.ModelAdmin):
    list_display = ('process','current_step', 'status', 'created_by', 'created_at', 'updated_at')
    list_filter = ('status', 'created_by')
 

@admin.register(ProcessStage)
class ProcessStageAdmin(admin.ModelAdmin):
    list_display = ('process', 'title', 'order')
    list_filter = ('process',)

class QuestionInline(admin.TabularInline):
    model = Question
    extra = 1

@admin.register(Form)
class FormAdmin(admin.ModelAdmin):
    list_display = ('title', 'process_stage', 'created_at', 'updated_at')
    list_filter = ('process_stage',)
    inlines = [QuestionInline]

@admin.register(QuestionType)
class QuestionTypeAdmin(admin.ModelAdmin):
    list_display = ('type_name',)

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('title', 'form', 'question_type', 'required')
    list_filter = ('form', 'question_type')

@admin.register(Choice)
class ChoiceAdmin(admin.ModelAdmin):
    list_display = ('question', 'choice_text')

@admin.register(Response)
class ResponseAdmin(admin.ModelAdmin):
    list_display = ('form', 'responder', 'responder_ip', 'created_at', 'updated_at')
    list_filter = ('form', 'responder')

@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ('response', 'question', 'answer_text')
    list_filter = ('response', 'question')
