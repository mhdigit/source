from django.contrib import admin
from .models import Form, Questions, Responses, Answer ,Choices





class QuestionAdmin(admin.ModelAdmin):
    model = Questions

class AnswerAdmin(admin.ModelAdmin):
    model = Answer
class ChoicesAdmin(admin.ModelAdmin):
    model = Choices
  

class FormAdmin(admin.ModelAdmin):
    model = Form
    list_display = ('title', 'description')
    search_fields = ('title',)



class ResponseAdmin(admin.ModelAdmin):
    model = Responses
   

admin.site.register(Form, FormAdmin)
admin.site.register(Questions, QuestionAdmin)
admin.site.register(Responses, ResponseAdmin)
admin.site.register(Answer, AnswerAdmin)
admin.site.register( Choices,ChoicesAdmin)

